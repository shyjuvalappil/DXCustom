import StarRate from "./StarRate";

function App ()
{
  return(
      <StarRate/>
  )
}

export default App;
